/**
 * What a module declares about itself, as data (ARCHITECTURE.md §13.1).
 *
 * A manifest is **data-only TypeScript**: type annotations and object literals, nothing else. Three
 * consumers depend on that and each one would break differently if it stopped being true:
 *
 *  * the **main process** validates a `type: "module"` job action against `MANIFESTS` before a window
 *    exists (§13.6), so this file is typechecked by `tsconfig.node.json` and must name no DOM type;
 *  * the **renderer** builds the switcher, the key rows and the reader hook from the same objects,
 *    so it is typechecked by `tsconfig.web.json`;
 *  * a **Node script** may import a manifest directly, so the syntax stays *erasable* — no enums, no
 *    namespaces, no parameter properties, nothing that has to be executed to be understood.
 *
 * `modules.test.ts` asserts the "data only" half by reading the sources: a manifest may import
 * nothing but `./manifest-types`.
 *
 * **Ids.** A module id is `<vendor>.<name>` (`tetravox.hello`). Command, reader, writer and operation
 * ids are **unprefixed inside a manifest**; the host namespaces them as `<moduleId>/<id>` wherever
 * they leave the module — so a manifest never repeats its own id, and two modules can both declare
 * `save` without colliding.
 */
/**
 * The same pool as a value, because the resolver and its tests both need to *enumerate* it.
 *
 * It is here rather than in the renderer so the union and the array can never drift: a key added to
 * one and not the other fails `modules.test.ts`, which checks them against each other and then
 * probes every entry through the live `resolveKey`.
 */
export const MODULE_KEY_POOL = [
    'a',
    's',
    'd',
    'f',
    'g',
    'n',
    'p',
    't',
    'z',
    'Delete',
    'Backspace',
];
/**
 * The keys the **engine** binds on the canvas (§7.5), which no `resolveKey` probe can reveal because
 * `keymap.ts` correctly refuses to know about them: `Space` (the pan modifier), `Esc`, `+`/`=` and
 * `-`/`_` (zoom the pane under the pointer) and `r` (fit).
 *
 * A module key must miss all of them as well as everything `resolveKey` claims.
 */
export const ENGINE_RESERVED_KEYS = [
    ' ',
    'Escape',
    '+',
    '=',
    '-',
    '_',
    'r',
    'R',
];
/**
 * `{stem}` — a basename without its trailing extension. **The one definition** (§13.1, §13.6).
 *
 * Three places substitute this token and all three have to produce the same string: main's sibling
 * admission (`main/module-io.ts`), the renderer's sibling instantiation
 * (`renderer/src/modules/siblings.ts`), and the sEEG module's editlog name
 * (`renderer/src/modules/seeg/bids.ts`). They were three functions until 2026-08-30 and disagreed
 * about a dotted name — main admitted `sub-01_electrodes.v2_editlog.json` while the module wrote
 * `sub-01_electrodes_editlog.json`, so the write was refused by the very list that existed to
 * permit it. It lives here because this file is the module *contract*, main-safe by construction
 * (no DOM type, no `node:` import, nothing that has to be executed), which makes it the only place
 * both processes may import from.
 *
 * The rule: **one suffix, and a compression suffix takes the extension in front of it with it.**
 * `sub-01_electrodes.tsv` → `sub-01_electrodes`, and `sub-01_ct.nii.gz` → `sub-01_ct`, because
 * `sub-01_ct.nii` is not a stem anyone would write a sibling against. A name with no dot, or one
 * whose only dot begins it (`.hidden`), is its own stem.
 *
 * "One suffix" rather than "the whole extension chain" is the half chosen deliberately: it keeps the
 * token **injective** over a directory. `a.tsv` and `a.v2.tsv` get different stems, so two tables
 * sitting beside each other can never claim one `{stem}_editlog.json` — under a chain rule they
 * collapse to the same name and the second save silently overwrites the first one's provenance.
 */
export function stemOf(name) {
    const cut = (value) => {
        const dot = value.lastIndexOf('.');
        return dot > 0 ? value.slice(0, dot) : null;
    };
    const lower = name.toLowerCase();
    if (lower.endsWith('.gz') || lower.endsWith('.bz2') || lower.endsWith('.zip')) {
        const once = cut(name);
        if (once !== null)
            return cut(once) ?? once;
    }
    return cut(name) ?? name;
}
/**
 * The host API's integer version (§13.1).
 *
 * A manifest names the version it was written against in `hostApi`. Host changes are **additive**
 * under §12.3, exactly like `api.ts`; a breaking change bumps this integer with a `DECISIONS.md`
 * line, and the registry test then refuses every stale manifest rather than letting one run against
 * a surface that no longer means what it said.
 */
export const MODULE_HOST_VERSION = 1;
