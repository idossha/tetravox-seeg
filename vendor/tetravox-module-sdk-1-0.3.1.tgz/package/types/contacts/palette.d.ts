/**
 * The twelve colours a contact set cycles across its groups.
 *
 * Slicer's `SEEGContactEditor._PALETTE`, value for value, so the same subject opened in either tool
 * shows the same electrode in the same colour — which is the whole point of copying a palette rather
 * than picking a nicer one. It is the ColorBrewer "paired"-family set the module chose for being
 * distinguishable under the common forms of colour blindness.
 *
 * Cycled by **index within the set's group list**, not hashed from the name: a hash gives two
 * neighbouring shafts the same colour often enough to matter, and the group list is the file's own
 * order, which is stable across a reload.
 */
import type { vec4 } from '../engine';
export declare const CONTACT_PALETTE: readonly vec4[];
/** The colour for the `index`-th group, cycling. */
export declare function paletteColor(index: number): vec4;
/** `#rrggbb` for a swatch. Alpha is dropped: a swatch is opaque. */
export declare function cssColor(color: vec4): string;
