/**
 * Reading and writing a table of contacts — the tolerant reader in, the canonical BIDS writer out.
 *
 * **Tolerant in, canonical out**, which is the shape every clinical importer ends up with: the file a
 * user has is whatever their site exports — a comma-separated sheet, a Slicer `.fcsv`, a table with
 * `R`/`A`/`S` instead of `x`/`y`/`z`, one row short of the header — and the file this writes is a
 * BIDS-iEEG `electrodes.tsv` that `seegprep` reads back. Slicer's `_readTable` /`_resolveColumns`
 * are the reference for the tolerance, and `seegprep/io/localization.py` for the output.
 *
 * Three properties are load-bearing, and each one is a defect somebody had:
 *
 *  * **The original columns survive.** A `csc` column bridging to `channels.tsv`, a `hu_peak`, a
 *    `manufacturer` — none of them mean anything here, and dropping them would quietly delete the
 *    localiser's output. Every cell that came in goes back out, in the file's own column order, with
 *    `electrode` / `contact` / `status` appended only if they were not already there.
 *  * **Floats are formatted like Python's `repr`, not like `String(x)`.** `seegprep` writes `repr`
 *    so its tables round-trip bit for bit, and JavaScript disagrees with it in three places:
 *    `String(3)` is `3` where `repr(3.0)` is `3.0`, `String(1e-7)` is `1e-7` where `repr` is
 *    `1e-07`, and the two switch to exponent notation at different magnitudes. {@link formatFloat}
 *    is Python's rule, with a JS/Python fixture pinning it (`testdata/manifest.json`, `seeg.floats`).
 *  * **An unchanged contact is written back byte for byte.** Its cells are the ones it arrived with
 *    and its coordinate is the `repr` of the double the file parsed to, so a save with no edits is a
 *    no-op diff — which is what makes `status` mean something.
 */
import type { vec3 } from '../engine';
import type { ContactSet, Contact } from './model';
/** What the header was separated by. Reported so a "column not found" error can say it. */
export type Delimiter = 'tab' | 'comma' | 'semicolon' | 'whitespace';
/** The file's own name for each field this reader understands, or `null` when it has none. */
export interface ColumnMap {
    name: string | null;
    x: string | null;
    y: string | null;
    z: string | null;
    electrode: string | null;
    contact: string | null;
    status: string | null;
}
export interface ParsedTable {
    /** The header, in the file's order. */
    fieldnames: string[];
    delimiter: Delimiter;
    /** One record per data row, keyed by the file's own column names. */
    rows: Record<string, string>[];
    columns: ColumnMap;
    format: 'table' | 'fcsv';
    /** The frame the coordinates were written in. An `.fcsv` may say LPS; a BIDS tsv is always RAS. */
    coordinateSystem: 'RAS' | 'LPS';
}
/** A table this reader cannot use, with the delimiter and the columns it did find. */
export declare class ContactTableError extends Error {
    constructor(message: string);
}
/**
 * Which of the file's columns each field is, case- and space-insensitively.
 *
 * The `R`/`A`/`S` fallback runs only when `x`/`y`/`z` are all missing, so a table with both an `x`
 * and a stray `r` column is read the way it was written.
 */
export declare function resolveColumns(fieldnames: readonly string[]): ColumnMap;
/**
 * Parse an electrode table, tolerantly.
 *
 * Handled: a UTF-8 BOM, CRLF, blank lines anywhere, tab / comma / semicolon / whitespace, headers in
 * any case with spaces around them, `R`/`A`/`S` instead of `x`/`y`/`z`, and a **ragged** row — a
 * hand-edited sheet legitimately has one, and truncating to the shorter of header and row is what
 * every tolerant reader does. A missing required column is the one thing that throws, and the
 * message names the delimiter and the columns it found, because "column not found" without those
 * two facts is the least useful error in data work.
 */
export declare function parseTable(text: string): ParsedTable;
export interface ContactSetResult {
    set: ContactSet;
    /** The zero-padding width the file's own names use — what a relabel must reproduce. */
    namePad: number;
    /** Rows that were dropped, and why. Shown as a toast rather than failing the load. */
    warnings: string[];
}
/**
 * Turn a parsed table into a {@link ContactSet}.
 *
 * Ids are `c<row>`, 1-based over the **file's** rows, so a contact keeps its identity across a
 * reload of the same file and a scene block written against it still resolves. Contacts stay in file
 * order — §4.4's rule that the array is drawing order and `ordinal` is anatomy — and the panel sorts
 * by ordinal when it lists them.
 */
export declare function contactSetFrom(parsed: ParsedTable): ContactSetResult;
/**
 * A float formatted exactly as Python's `repr` writes it.
 *
 * `toExponential()` with no argument is the shortest round-tripping digit string by specification,
 * which is the same set of digits CPython's David Gay / Grisu shortest repr produces — so the only
 * work here is Python's *layout* of them: always a decimal point, a two-digit signed exponent, and
 * the two thresholds above.
 *
 * Non-finite values become `n/a`: BIDS's missing-value token, and what `seegprep`'s own writer
 * emits for a NaN.
 */
export declare function formatFloat(value: number): string;
/** BIDS's missing-value token. `seegprep` writes it and its reader expects it. */
export declare const MISSING = "n/a";
/** What the writer needs to remember about the file that was read. */
export interface WriteSource {
    fieldnames: readonly string[];
    columns: ColumnMap;
}
/** The canonical column set for a table that had none of its own (a new set, or an `.fcsv`). */
export declare const CANONICAL_FIELDNAMES: readonly string[];
/**
 * The columns the output will have: the file's own, then `electrode` / `contact` / `status` if they
 * were not already among them under any of their aliases.
 */
export declare function outputFieldnames(source: WriteSource): string[];
/**
 * The table, as the text to write: tab-separated, **LF**, one trailing newline.
 *
 * Rows come out grouped by electrode in the set's group order and ordered by `ordinal` inside a
 * group — the clinical order, and the order `seegprep` writes — rather than the array's drawing
 * order. Every cell a contact arrived with is written back unless this writer owns it; a cell the
 * file never had (a contact added here) is `n/a`, because BIDS says a missing value is `n/a` and an
 * empty cell in a tab-separated file is indistinguishable from a ragged row.
 *
 * CRLF is a Slicer defect this deliberately does not reproduce: `csv.DictWriter` with the default
 * `\r\n` is what put carriage returns into hand-edited tables, and `seegprep` writes LF.
 */
export declare function writeTable(set: ContactSet, source: WriteSource): string;
/** A fresh contact for a position the user placed, with no row behind it. */
export declare function newContact(id: string, group: string, ordinal: number, position: vec3, pad: number): Contact;
