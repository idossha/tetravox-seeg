/**
 * `<stem>_editlog.json` — the provenance sidecar a save writes beside the table.
 *
 * **It is a contract with another program, not a log.** `seegprep`'s CLI globs
 * `<derivatives>/sub-<id>/ieeg/*_electrodes_editlog.json` and refuses to overwrite a subject that
 * has one unless `--force` (`seegprep/cli.py::_editlog_files`), so the file's *name* is the signal
 * and the counts inside it are what a reader checks first. Every key Slicer's editor wrote is
 * written here with the same name and the same meaning — `edited_utc`, `source_tsv`, `output_tsv`,
 * `backup`, `n_electrodes`, `n_contacts`, `added`, `edited`, `tool` — so a pipeline that already
 * parses one keeps working.
 *
 * **What is new is the per-contact diff.** Slicer wrote counts only, which answers "was this
 * hand-edited?" and not "what was changed?" — and the second question is the one a reviewer asks
 * three months later when the electrode is in a paper. Each entry names the contact, its electrode,
 * where it was, where it is, and how far that is; a deletion has no `to` and an addition has no
 * `from`. Counts stay beside them so the two can never disagree.
 *
 * **A relabel is a change even when nothing moved** (2026-08-30). Renumber and Re-fit rewrite names
 * and ordinals; a diff keyed on position alone reported `added: 0`, `edited: 0` and no entries at all
 * for the one edit that changes how a table's `csc` column maps onto the recording system. The
 * `renamed` change and the `renamed_from` field are additive beside Slicer's keys.
 */
import type { vec3 } from '../engine';
import type { ContactSet } from './model';
export declare const EDITLOG_SCHEMA = "tetravox.contacts/editlog@1";
/**
 * `renamed` is the fourth change, added 2026-08-30.
 *
 * A renumber rewrites names and ordinals and moves nothing, so it used to produce an editlog with
 * `added: 0`, `edited: 0` and no contact entries at all — silent about the one edit that rewires a
 * table's `csc`/channel mapping. It is a *change kind* rather than a flag on `edited` because a
 * contact can be renamed without moving, and the old→new pair is the thing a reader needs.
 */
export type EditlogChange = 'added' | 'edited' | 'deleted' | 'renamed';
export interface EditlogEntry {
    name: string;
    electrode: string;
    contact: number;
    change: EditlogChange;
    from?: [number, number, number];
    to?: [number, number, number];
    /** Euclidean, millimetres. Absent for an addition and a deletion. */
    shift_mm?: number;
    /** The name the table had, when a re-fit or a renumber changed it. */
    renamed_from?: string;
}
export interface EditlogElectrode {
    name: string;
    n_contacts: number;
    refit: boolean;
    renumbered: boolean;
    snapped: boolean;
}
export interface Editlog {
    schema: string;
    edited_utc: string;
    tool: string;
    source_tsv: string | null;
    output_tsv: string;
    backup: string | null;
    n_electrodes: number;
    n_contacts: number;
    added: number;
    edited: number;
    /**
     * How many contacts a relabel renamed without moving (2026-08-30).
     *
     * Additive beside the counts Slicer's editor wrote: a reader that knows only `added` / `edited` /
     * `deleted` is unaffected, and a log written before this key existed reads as zero, which is what
     * it was. The schema string does not move for it.
     */
    renamed: number;
    deleted: number;
    kept: number;
    snap_radius_mm: number;
    electrodes: EditlogElectrode[];
    contacts: EditlogEntry[];
}
/** A contact that was in the file and is not in the set any more. */
export interface DeletedContact {
    name: string;
    group: string;
    ordinal: number;
    position: vec3;
}
/** What the module remembers about which operations touched which electrode. */
export interface OperationRecord {
    refit: ReadonlySet<string>;
    renumbered: ReadonlySet<string>;
    snapped: ReadonlySet<string>;
}
export interface EditlogInput {
    set: ContactSet;
    deleted: readonly DeletedContact[];
    sourceTsv: string | null;
    outputTsv: string;
    backup: string | null;
    snapRadiusMm: number;
    tool: string;
    operations: OperationRecord;
    /** Injected so a test pins the timestamp rather than the clock. */
    now?: Date;
}
/** `YYYY-MM-DDTHH:MM:SSZ` — seconds precision, the form Slicer's editor wrote. */
export declare function utcSeconds(at: Date): string;
export declare function buildEditlog(input: EditlogInput): Editlog;
/** The text to write: two-space JSON with a trailing newline, like `json.dump(…, indent=2)`. */
export declare function formatEditlog(log: Editlog): string;
/**
 * The date an existing editlog records, for the "hand-edited on …" banner — or `null`.
 *
 * Deliberately tolerant: the file may have been written by Slicer's editor (no `schema`, counts
 * only) or by a later version of this one, and all the banner needs is the timestamp. Anything it
 * cannot read is "there is an editlog and it does not say when", which is still worth showing.
 */
export declare function editlogDate(text: string): string | null;
