/**
 * The line geometry every implanted contact set shares — PCA fit, spacing, projection, re-spacing.
 *
 * **Generic on purpose.** A depth electrode, a DBS lead and a laser fibre are all "n contacts on a
 * line", and every one of them wants the same four answers: which line, how far off it they are, how
 * evenly they are spaced, and where they would sit if they were even. What is *not* here is which
 * end is the tip and how far apart the contacts of a particular electrode model should be — those
 * are the geometry of one kind of hardware and live with the module that knows it
 * (`modules/seeg/shaft.ts`). See `README.md`.
 *
 * **No eigen solver in the tree.** gl-matrix has none, so the fit is a hand-written cyclic Jacobi
 * rotation over the 3×3 covariance — twelve lines, exact for a symmetric matrix, and it converges in
 * a handful of sweeps for a case this small. numpy's `svd(pts - c)[2][0]` is the reference the
 * fixtures are generated from (`scripts/gen-fixtures.py`, the `seeg` block).
 *
 * **The axis sign is pinned, and it has to be.** An eigenvector is only defined up to sign — numpy's
 * SVD picks whichever LAPACK happens to return — so a fixture comparing this axis against that one
 * would be pinning a tie-break rather than a rule. {@link canonicaliseAxis} makes the component of
 * largest magnitude positive, on both sides of the fixture. Everything a caller actually reads
 * (`rmsMm`, the spacing CV, the pitch, the projected points) is sign-invariant anyway; the ordering
 * `orderAlong` returns is not, which is exactly why the convention exists.
 */
import type { vec3 } from '../engine';
/** A line through a point cloud: `centroid + t * axis`. */
export interface LineFit {
    /** The mean of the points. */
    centroid: vec3;
    /** Unit direction, sign-canonicalised (see {@link canonicaliseAxis}). */
    axis: vec3;
    /** Each input point's signed distance along `axis` from `centroid`, in input order. */
    t: number[];
    /** Root-mean-square perpendicular distance to the line, in millimetres. */
    rmsMm: number;
}
/** What a shaft looks like as three numbers. `null` where there is nothing to measure. */
export interface LineMetrics {
    rmsMm: number;
    /** `std(gaps) / mean(gaps)` — population std, like numpy's default. `null` for fewer than 3. */
    spacingCv: number | null;
    /** The **median** observed gap, in millimetres — robust to one missing contact. `null` for < 2. */
    pitchMm: number | null;
}
/** The mean position, or `null` for an empty set. */
export declare function centroidOf(points: readonly vec3[]): vec3 | null;
/**
 * Flip `axis` so its largest-magnitude component is positive.
 *
 * The one convention that lets a JavaScript fit and a numpy fit be compared number for number. On an
 * exact tie between two components the earlier one decides, so the rule is total.
 */
export declare function canonicaliseAxis(axis: vec3): vec3;
export declare function dominantEigenvector(m: readonly number[]): vec3;
/**
 * The PCA line through `points`, or `null` for fewer than two.
 *
 * `rmsMm` is `sqrt(mean(|p − (c + t·axis)|²))` — Slicer's `_fitLine`, which is the number its Edit
 * panel calls "line-RMS" and the one a user compares between two refits.
 */
export declare function fitLine(points: readonly vec3[]): LineFit | null;
/** numpy's `median`: the middle of the sorted values, or the mean of the two middle ones. */
export declare function median(values: readonly number[]): number | null;
/** Population standard deviation (`ddof = 0`), matching numpy's default. */
export declare function standardDeviation(values: readonly number[]): number | null;
/** The gaps between consecutive projections, sorted along the axis. */
export declare function sortedGaps(t: readonly number[]): number[];
/** {@link LineFit} reduced to the three numbers a panel shows. `null` for fewer than two points. */
export declare function lineMetrics(points: readonly vec3[]): LineMetrics | null;
/** The foot of the perpendicular from `p` onto the line. */
export declare function projectOntoLine(p: vec3, centroid: vec3, axis: vec3): vec3;
/** Indices of `points`, ordered by their projection onto the fitted line (low `t` first). */
export declare function orderAlong(points: readonly vec3[]): number[];
/**
 * `points.length` positions on the fitted line, evenly spaced at the **median** observed gap and
 * starting at the lowest projection — Slicer's `refitShaft` arithmetic.
 *
 * The result is in **ascending `t` order**, not in the input's order: slot `k` is the `k`-th contact
 * from the low end of the shaft. Which end that is anatomically is not this function's question —
 * the caller pairs the slots with contacts once it has decided which end is the tip.
 *
 * Median rather than mean because a shaft that lost one contact to detection has one gap of twice
 * the pitch, and a mean would stretch every other contact to accommodate it.
 */
export declare function respaceEven(points: readonly vec3[]): vec3[] | null;
/** Euclidean distance in millimetres. */
export declare function distanceMm(a: vec3, b: vec3): number;
