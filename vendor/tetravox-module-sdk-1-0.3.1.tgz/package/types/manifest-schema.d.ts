/**
 * `manifest.json` → {@link InstalledManifest}, or a list of everything wrong with it (§13.1,
 * downloadable extensions, 2026-08-30).
 *
 * **One schema, two carriers.** A compiled-in module writes its manifest as a TypeScript literal and
 * `tsc` checks it; a downloaded module ships the byte-for-byte same object as JSON, and nothing
 * checks it — so this file is what `tsc` is for the other carrier. `manifest.json` is
 * `ModuleManifest` and *nothing more*: entry file names, sizes and hashes belong to the release and
 * to the install receipt, never to a module's self-description, which is why an unknown key is an
 * error rather than something to ignore.
 *
 * **Every problem at once**, the `job.ts#validateJob` house style ("a validator that stops at the
 * first bad key turns one round of fixing into four"). A module author gets one list, not four
 * builds.
 *
 * It lives in `src/modules/` — the data-only directory — because it imports **only**
 * `./manifest-types`, which is exactly what `modules.test.ts`'s "src/modules is data only" block
 * requires. That is also what lets main validate an installed manifest before a window exists, and
 * what lets the SDK re-emit this file as plain ESM so a module repository can validate its own
 * `manifest.json` with `node` and no install.
 *
 * Its test is `main/manifest-schema.test.ts`, deliberately **outside** this directory: the data-only
 * source scan rejects an `import … from 'vitest'` in here.
 */
import type { ArgType, InstalledManifest } from './manifest-types';
/** `<vendor>.<name>`, the same shape `modules.test.ts` asserts over the compiled-in barrel. */
export declare const MANIFEST_ID: RegExp;
/** A contributed id — command, reader, writer, operation. Unprefixed; the host namespaces it. */
export declare const CONTRIBUTED_ID: RegExp;
/** semver `MAJOR.MINOR.PATCH` with an optional pre-release/build tail. */
export declare const SEMVER: RegExp;
/**
 * A writer's sibling **template** before substitution.
 *
 * The one definition that matters is `main/module-io.ts#SIBLING_TEMPLATE` — the list main admits
 * against — and this is a copy, because `src/modules` may not import from `main`. They are checked
 * against each other in `main/manifest-schema.test.ts`: a manifest that declares a template main
 * would refuse is a module whose save is rejected by the very list that exists to permit it, which
 * is the bug this rule is here to catch at review time instead of at save time.
 */
export declare const SIBLING_TEMPLATE: RegExp;
/** The four activation routes (§13.1). */
export declare const ACTIVATION_ROUTES: readonly string[];
/** Every `ArgType` of the job envelope (§13.6), as a value the validator can test membership in. */
export declare const ARG_TYPES: readonly ArgType[];
export type ManifestValidation = {
    ok: true;
    manifest: InstalledManifest;
} | {
    ok: false;
    errors: string[];
};
/**
 * Validate a parsed `manifest.json`.
 *
 * Returns the manifest **as read**, never a repaired one: a validator that fills in defaults is a
 * second source of truth for what a module declared, and the consent sheet shows the user what the
 * manifest says. Either every rule holds and this is the object, or none of it is used.
 */
export declare function validateManifest(raw: unknown): ManifestValidation;
/**
 * The permission list the consent sheet shows, **derived from the manifest** and from nothing else
 * (§13.1, 2026-08-30).
 *
 * One schema, no second source of truth: a module cannot ask for less in a separate `permissions`
 * block than its manifest lets it do. The registry index carries a copy so a catalogue card can be
 * drawn without downloading anything, and an installed manifest that disagrees with the index entry
 * is a hard install failure — the *installed* manifest is what the user consents to.
 */
export declare function derivePermissions(manifest: InstalledManifest): string[];
